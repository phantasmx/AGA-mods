Collab Mini Actresses Full Size Mod.

Makes collab mini actresses full sized.
Applies currently to Sol Raptor, Gourai, Stylet, Baselard, Hresvelgr.

Use at your own risk!

For Alice Gear Aegis Ver.1.34.0 (PC Only)

To install:
	Copy Assembly-CSharp.dll to \alice_main_Data\Managed\ folder. Replace the existing file.
	Protect the file before starting the game to prevent DMM client fron replacing it.
	
To uninstall:
	Delete Assembly-CSharp.dll from \alice_main_Data\Managed\ folder. DMM client will redownload original file on next game start.