Replaces horns on succubus accessory with new horns from July 2020 accessory.

PC Mod:
To install, drop the files from `PC Mod` folder to C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス
To uninstall, drop the files from `PC Original` folder to C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス

Android Mod:
To install, drop the files from `Android Mod` folder to .../Android/data/jp.colopl.alice/files
To uninstall, drop the files from `Android Original` folder to .../Android/data/jp.colopl.alice/files
