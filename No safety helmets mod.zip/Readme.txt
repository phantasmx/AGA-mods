No safety helmets mod (PC / Android)

Removes safety helmets accessory for better appreciation of alternative hairstyles

PC Mod:
To install, drop the files from `PC` folder to C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス
To uninstall, delete the files from C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス

Android Mod:
To install, drop the files from `Android` folder to .../Android/data/jp.colopl.alice/files
To uninstall, delete the files from .../Android/data/jp.colopl.alice/files
