Ti2 and IA Rehtona head accessory swap to heart earrings (PC / Android)

PC Mod:
To install, drop the file from `PC\Mod` folder to C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス
To uninstall, drop the file from `PC\Original` folder to C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス

Android Mod:
To install, drop the file from `Android\Mod` folder to .../Android/data/jp.colopl.alice/files
To uninstall, drop the file from `Android\Original` folder to .../Android/data/jp.colopl.alice/files
