Full Size mod
- makes collab mini characters normal sized (Frame Arms Girls and SOL Raptor)
- to install, unzip this mod to "alicegearaegisexe" folder (overwrite everything if prompted)