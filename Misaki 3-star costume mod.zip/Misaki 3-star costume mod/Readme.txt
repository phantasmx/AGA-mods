Misaki 3-star costume mod (PC / Android)
Short skirt / skirtless variants

PC Mod:
To install, drop the file from either `PC\Short skirt` or `PC\Skirtless` folder to C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス
To uninstall, drop the files from `PC\Original` folder to C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス

Android Mod:
To install, drop the file from either `Android\Short skirt` or `Android\Skirtless` folder to .../Android/data/jp.colopl.alice/files
To uninstall, drop the file from `Android\Original` folder to .../Android/data/jp.colopl.alice/files
