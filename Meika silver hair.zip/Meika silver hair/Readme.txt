Meika silver hair (PC / Android)

PC Mod:
To install, drop the file from `PC` folder to `C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス`
To uninstall, delete the file from `C:\Users\...\AppData\LocalLow\COLOPL, Inc_\アリス・ギア・アイギス`

Android Mod:
To install, drop the file from `Android` folder to `.../Android/data/jp.colopl.alice/files`
To uninstall, delete the file from `.../Android/data/jp.colopl.alice/files`